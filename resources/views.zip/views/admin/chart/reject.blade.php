<div class="card" style="height:590px">
    <div class="card-body">
        <canvas id="reject_chart"></canvas>
    </div>
</div>