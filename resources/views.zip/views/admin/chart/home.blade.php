<div class="card" style="height:590px">
    <div class="card-body">
        
        <canvas id="progres" style="height:100%"></canvas>

    </div>
</div>