<div class="card" style="height:590px">
    <div class="card-body">
       <canvas id="property_chart"></canvas>
    </div>
</div>