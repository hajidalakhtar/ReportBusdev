@php
$ready_jkt_1 = \DB::select('SELECT * FROM `jakarta_1` WHERE `PROGRESS_STATUS` = "READY TO SELL"');
$ready_jkt_2 = \DB::select('SELECT * FROM `jakarta_2` WHERE `PROGRESS_STATUS` = "READY TO SELL"');
$ready_jkt_3 = \DB::select('SELECT * FROM `jakarta_3` WHERE `PROGRESS_STATUS` = "READY TO SELL"');
$ready_semarang = \DB::select('SELECT * FROM `semarang` WHERE `PROGRESS_STATUS` = "READY TO SELL"');
$ready_surabaya = \DB::select('SELECT * FROM `surabaya` WHERE `PROGRESS_STATUS` = "READY TO SELL"');
// dd($ready_jkt_1);
$ready_hp_jkt_1 = \DB::select('SELECT `HP_PORT` FROM `Ready_jakarta_1` WHERE `PROGRESS_STATUS` = "READY TO SELL"');
if ($ready_hp_jkt_1 == []) {
$ready_hp_jkt_1 = 0;
}else{
$hasil = 0;
for ($i=0; $i < Count($ready_hp_jkt_1) ; $i++) { $hasil=$ready_hp_jkt_1[$i]->HP_PORT + $hasil;
  }
  $ready_hp_jkt_1 = $hasil;
  };
  $ready_hp_jkt_2 = \DB::select('SELECT `HP_PORT` FROM `Ready_jakarta_2` WHERE `PROGRESS_STATUS` = "READY TO SELL"');
  if ($ready_hp_jkt_2 == []) {
  $ready_hp_jkt_2 = 0;
  }else{
  $hasil = 0;
  for ($i=0; $i < Count($ready_hp_jkt_2) ; $i++) { $hasil=$ready_hp_jkt_2[$i]->HP_PORT + $hasil;
    }
    $ready_hp_jkt_2 = $hasil;
    };
    $ready_hp_jkt_3 = \DB::select('SELECT `HP_PORT` FROM `Ready_jakarta_3` WHERE `PROGRESS_STATUS` = "READY TO
    SELL"');
    if ($ready_hp_jkt_3 == []) {
    $ready_hp_jkt_3 = 0;
    }else{
    $hasil = 0;
    for ($i=0; $i < Count($ready_hp_jkt_3) ; $i++) { $hasil=$ready_hp_jkt_3[$i]->HP_PORT + $hasil;
      }
      $ready_hp_jkt_3 = $hasil;
      };
      $ready_hp_semarang = \DB::select('SELECT `HP_PORT` FROM `Ready_semarang` WHERE `PROGRESS_STATUS` = "READY TO
      SELL"');
      if ($ready_hp_semarang == []) {
      $ready_hp_semarang = 0;
      }else{
      $hasil = 0;
      for ($i=0; $i < Count($ready_hp_semarang) ; $i++) { $hasil=$ready_hp_semarang[$i]->HP_PORT + $hasil;
        }
        $ready_hp_semarang = $hasil;
        };
        $ready_hp_surabaya = \DB::select('SELECT `HP_PORT` FROM `Ready_surabaya` WHERE `PROGRESS_STATUS` =
        "READY TO SELL"');
        if ($ready_hp_surabaya == []) {
        $ready_hp_surabaya = 0;
        }else{
        $hasil = 0;
        for ($i=0; $i < Count($ready_hp_surabaya) ; $i++) { $hasil=$ready_hp_surabaya[$i]->HP_PORT +
          $hasil;
          }
          $ready_hp_surabaya = $hasil;
          };
          @endphp

          <script>
            var ctx = document.getElementById("progress");
var myChart = new Chart(ctx, {
  type: 'doughnut',
  data: {
    labels: ['SUBMIT PROPOSAL', "NEGOTIATION 1 - BUSINESS SCHEME" ,'SITE SURVEY', 'BOQ & APD', 'ROLL OUT',"Pnl Progress","PKS REVIEW","SIGNED PKS"],
    datasets: [{
      label: '# of Tomatoes',
      data: [{{$submit_proposal}},{{$negotiation}}, {{$site_survey}}, {{$boq}}, {{$roll}},{{$pnl}},{{$pks_review}},{{$Sign_pks}}],
      backgroundColor: [
        '#07B1FA',
        '#8DA9C4',
        '#0679FB',
        '#6C757D',
        '#FD803A',
        '#FFEA4A',
        '#D94360',
        '#001F3F',
        'rgba(75, 192, 192, 0.2)',
        'rgba(75, 192, 192, 0.2)',
        'rgba(75, 192, 192, 0.2)',
      ],
    
      borderWidth: 1
    }]
  },
  options: {
      legend: {
            display: false,
            },
   	cutoutPercentage: 40,
    responsive: false,

  }
});


var ctx = document.getElementById("rts");
var myChart = new Chart(ctx, {
  type: 'doughnut',
  data: {
    labels: ['OK', 'WARNING', 'CRITICAL', 'UNKNOWN'],
    datasets: [{
      label: '# of Tomatoes',
      data: [12, 19, 3, 5],
      backgroundColor: [
        'rgba(255, 99, 132, 0.5)',
        'rgba(54, 162, 235, 0.2)',
        'rgba(255, 206, 86, 0.2)',
        'rgba(75, 192, 192, 0.2)'
      ],
      borderColor: [
        'rgba(255,99,132,1)',
        'rgba(54, 162, 235, 1)',
        'rgba(255, 206, 86, 1)',
        'rgba(75, 192, 192, 1)'
      ],
      borderWidth: 1
    }]
  },
  options: {
      legend: {
            display: false,
            },
   	cutoutPercentage: 40,
    responsive: false,

  }
});
var ctx = document.getElementById("property");
var myChart = new Chart(ctx, {
  type: 'doughnut',
  data: {
    labels: ['Office Building', 'Apartemen', 'Ruko/Rukan', 'Landed House','Pergudangan','Mix Use'],
    datasets: [{
      label: '# of Tomatoes',
      
      data: [{{$office_building}}, {{$apertemen}}, {{$ruko}}, {{$landed_house}} ,{{$pergudangan}},{{$mix}}],
      backgroundColor: [
        'rgba(255, 99, 132, 0.5)',
        'rgba(54, 162, 235, 0.2)',
        'rgba(255, 206, 86, 0.2)',
        'rgba(75, 192, 192, 0.2)'
      ],
      borderColor: [
        'rgba(255,99,132,1)',
        'rgba(54, 162, 235, 1)',
        'rgba(255, 206, 86, 1)',
        'rgba(75, 192, 192, 1)'
      ],
      borderWidth: 1
    }]
  },
  options: {
      legend: {
            display: false,
            },
   	cutoutPercentage: 40,
    responsive: false,

  }
});

var ctx = document.getElementById("rts");
var myChart = new Chart(ctx, {
  type: 'doughnut',
  data: {
    labels: ['JAKARTA 1', 'JAKARTA 2', 'JAKARTA 3', 'SEMARANG',"SURABAYA"],
    datasets: [{
      label: '# of Tomatoes',
      data: [{{Count($ready_jkt_1)}}, {{Count($ready_jkt_2)}}, {{Count($ready_jkt_3)}}, {{Count($ready_semarang)}},{{Count($ready_surabaya)}}],
      backgroundColor: [
        'rgba(255, 99, 132, 0.5)',
        'rgba(54, 162, 235, 0.2)',
        'rgba(255, 206, 86, 0.2)',
        'rgba(75, 192, 192, 0.2)'
      ],
      borderColor: [
        'rgba(255,99,132,1)',
        'rgba(54, 162, 235, 1)',
        'rgba(255, 206, 86, 1)',
        'rgba(75, 192, 192, 1)'
      ],
      borderWidth: 1
    }]
  },
  options: {
      legend: {
            display: false,
            },
   	cutoutPercentage: 40,
    responsive: false,

  }
});





var ctx = document.getElementById("homepass");
var myChart = new Chart(ctx, {
  type: 'doughnut',
  data: {
    labels: ['JAKARTA 1', 'JAKARTA 2', 'JAKARTA 3', 'SEMARANG',"SURABAYA"],
    datasets: [{
      label: '# of Tomatoes',
      data: [{{$ready_hp_jkt_1}}, {{$ready_hp_jkt_2}}, {{$ready_hp_jkt_3}}, {{$ready_hp_semarang}},{{$ready_hp_surabaya}}],
      backgroundColor: [
        'rgba(255, 99, 132, 0.5)',
        'rgba(54, 162, 235, 0.2)',
        'rgba(255, 206, 86, 0.2)',
        'rgba(75, 192, 192, 0.2)'
      ],
      borderColor: [
        'rgba(255,99,132,1)',
        'rgba(54, 162, 235, 1)',
        'rgba(255, 206, 86, 1)',
        'rgba(75, 192, 192, 1)'
      ],
      borderWidth: 1
    }]
  },
  options: {
      legend: {
            display: false,
            },
   	cutoutPercentage: 40,
    responsive: false,

  }
});










var ctx = document.getElementById("reject");
var myChart = new Chart(ctx, {
  type: 'doughnut',
  data: {
    labels: ['Exclusive', 'Limited ISP Provider', 'IKR/OSP isn t recommend', 'PnL calculation is not meet minimum margin profit' ,'Sales isn t recommend','Business Scheme is not meet SOP'],
    datasets: [{
      label: '# of Tomatoes',
      data: [{{$REJECT_1}}, {{$REJECT_2}}, {{$REJECT_3}}, {{$REJECT_4}},{{$REJECT_5}},{{$REJECT_6}}],
      backgroundColor: [
        'rgba(255, 99, 132, 0.5)',
        'rgba(54, 162, 235, 0.2)',
        'rgba(255, 206, 86, 0.2)',
        'rgba(75, 192, 192, 0.2)'
      ],
      borderColor: [
        'rgba(255,99,132,1)',
        'rgba(54, 162, 235, 1)',
        'rgba(255, 206, 86, 1)',
        'rgba(75, 192, 192, 1)'
      ],
      borderWidth: 1
    }]
  },
  options: {
      legend: {
            display: false,
            },
   	cutoutPercentage: 40,
    responsive: false,

  }
});

      var areaChartData = {
        labels: ['SLA'],
        datasets: [{
                  label: 'SUBMIT PROPOSAL >  NEGOTIATION 1 - BUSINESS SCHEME',
                  backgroundColor: 'rgba(60,141,188,0.9)',
                  borderColor: 'rgba(60,141,188,0.8)',
                  pointRadius: false,
                  pointColor: '#3b8bba',
                  pointStrokeColor: 'rgba(60,141,188,1)',
                  pointHighlightFill: '#fff',
                  pointHighlightStroke: 'rgba(60,141,188,1)',
                  data: [{{$SUBMIT_PROPOSAL_NEGOTIATION_DIFF_AVERAGE}}]
          },
          {
                  label: 'NEGOTIATION 1 - BUSINESS SCHEME > SITE SURVEY',
                  backgroundColor: 'rgba(210, 214, 222, 1)',
                  borderColor: 'rgba(210, 214, 222, 1)',
                  pointRadius: false,
                  pointColor: 'rgba(210, 214, 222, 1)',
                  pointStrokeColor: '#c1c7d1',
                  pointHighlightFill: '#fff',
                  pointHighlightStroke: 'rgba(220,220,220,1)',
                  data: [{{$NEGOTIATION_SITE_SURVEY_DIFF_AVERAGE}}]
          },
          {
                  label: 'SITE SURVEY > BOQ, SITE SURVEY REPORT, DESIGN PROGRESS',
                  backgroundColor: 'rgba(210, 214, 222, 1)',
                  borderColor: 'rgba(210, 214, 222, 1)',
                  pointRadius: false,
                  pointColor: 'rgba(210, 214, 222, 1)',
                  pointStrokeColor: '#c1c7d1',
                  pointHighlightFill: '#fff',
                  pointHighlightStroke: 'rgba(220,220,220,1)',
                  data: [{{$SITE_SURVEY_BOQ_DIFF_AVERAGE}}]
            },
            {
                  label: 'BOQ, SITE SURVEY REPORT, DESIGN PROGRESS > PnL PROGRESS',
                  backgroundColor: 'rgba(210, 214, 222, 1)',
                  borderColor: 'rgba(210, 214, 222, 1)',
                  pointRadius: false,
                  pointColor: 'rgba(210, 214, 222, 1)',
                  pointStrokeColor: '#c1c7d1',
                  pointHighlightFill: '#fff',
                  pointHighlightStroke: 'rgba(220,220,220,1)',
                  data: [{{$BOQ_PNL_DIFF_AVERAGE}}]
            },
            {
                  label: 'PnL PROGRESS > PKS REVIEW',
                  backgroundColor: 'rgba(210, 214, 222, 1)',
                  borderColor: 'rgba(210, 214, 222, 1)',
                  pointRadius: false,
                  pointColor: 'rgba(210, 214, 222, 1)',
                  pointStrokeColor: '#c1c7d1',
                  pointHighlightFill: '#fff',
                  pointHighlightStroke: 'rgba(220,220,220,1)',
                  data: [{{$PNL_PKS_DIFF_AVERAGE}}]
            },
            {
                  label: 'PKS REVIEW > SIGNED PKS',
                  backgroundColor: 'rgba(210, 214, 222, 1)',
                  borderColor: 'rgba(210, 214, 222, 1)',
                  pointRadius: false,
                  pointColor: 'rgba(210, 214, 222, 1)',
                  pointStrokeColor: '#c1c7d1',
                  pointHighlightFill: '#fff',
                  pointHighlightStroke: 'rgba(220,220,220,1)',
                  data: [{{$PKS_SIGEND_PKS_DIFF_AVERAGE}}]
            },
            {
                  label: 'SIGNED PKS > ROLL-OUT PROGRESS',
                  backgroundColor: 'rgba(210, 214, 222, 1)',
                  borderColor: 'rgba(210, 214, 222, 1)',
                  pointRadius: false,
                  pointColor: 'rgba(210, 214, 222, 1)',
                  pointStrokeColor: '#c1c7d1',
                  pointHighlightFill: '#fff',
                  pointHighlightStroke: 'rgba(220,220,220,1)',
                  data: [{{$SIGEND_PKS_ROLL_OUT_DIFF_AVERAGE}}]
            },
            {
                  label: 'ROLL-OUT PROGRESS > READY TO SELL',
                  backgroundColor: 'rgba(210, 214, 222, 1)',
                  borderColor: 'rgba(210, 214, 222, 1)',
                  pointRadius: false,
                  pointColor: 'rgba(210, 214, 222, 1)',
                  pointStrokeColor: '#c1c7d1',
                  pointHighlightFill: '#fff',
                  pointHighlightStroke: 'rgba(220,220,220,1)',
                  data: [{{$ROLL_OUT_READY_DIFF_AVERAGE}}]
            },
       
        ]
      }

var stackedBarChartCanvas = $('#stackedBarChart').get(0).getContext('2d')
    var stackedBarChartData = jQuery.extend(true, {}, areaChartData)
    
    var stackedBarChartOptions = {
    responsive: true,
    legend: {
    display: false,
    },
    maintainAspectRatio: false,
    scales: {
    xAxes: [{
    stacked: true,
    }],
    yAxes: [{
    stacked: true
    }]
    }
    }
    
    var stackedBarChart = new Chart(stackedBarChartCanvas, {
    type: 'horizontalBar',
    data: stackedBarChartData,
    options: stackedBarChartOptions
    })









          </script>