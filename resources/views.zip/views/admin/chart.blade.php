<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                1
            </div>
            <div class="col-md-6">
                1
            </div>
        </div>
    </div>
</div>