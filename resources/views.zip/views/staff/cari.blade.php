@extends('layouts.cari')
@include('staff.sidebar')

@section('content')

@include('staff.info')
@include('staff.content')

@endsection

@include('staff.javascript')