<p>Halo, Progress Status di <b>{{$building}}</b> sudah sampai <b>{{$status}}</b></p>
{{-- <p>{{ $website }}</p> --}}