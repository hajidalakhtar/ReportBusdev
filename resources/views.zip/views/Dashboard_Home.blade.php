@extends('layouts.admin')
@section('content')
<div class="tab-content" id="myTabContent">
    <div class="card">
        <div class="card-body" style="padding-top:0px">
            <div class="row justify-content-center">
                <div class="col border">
                    <div class="text-center">
                        <h5 class="mt-2">Progress</h5>
                        <canvas id="progress" class="text-center" width="150" height="100"
                            style="display:inline"></canvas>
                    </div>

                </div>
                <div class=" col border">
                    <div class="text-center">
                        <h5 class="mt-2">Ready To Sell</h5>
                        <canvas id="rts" class="text-center" width="150" height="100" style="display:inline"></canvas>
                    </div>
                </div>
                <div class="col border">
                    <div class="text-center">
                        <h5 class="mt-2">Reject</h5>
                        <canvas id="reject" class="text-center" width="150" height="100"
                            style="display:inline"></canvas>
                    </div>
                </div>
                <div class="col border">
                    <div class="text-center">
                        <h5 class="mt-2">Property</h5>
                        <canvas id="property" class="text-center" width="150" height="100"
                            style="display:inline"></canvas>
                    </div>
                </div>
                <div class="col border">
                    <div class="text-center">
                        <h5 class="mt-2">Homepass</h5>
                        <canvas id="homepass" class="text-center" width="150" height="100"
                            style="display:inline"></canvas>
                    </div>
                </div>

            </div>
            <div class="row">
                <div class="col-md-9">
                    <h5 class="mt-2">
                        Busdev By SLA
                    </h5>
                    <div>
                        <canvas id="stackedBarChart" style="height:230px; "></canvas>
                    </div>
                </div>
                <div class="col-md-3 border">
                    <h5 class="text-center">READY TO SELL</h5>
                    <table>
                        <tr>
                            <td>Bulding Name</td>
                            <td>HP </td>
                        </tr>
                        @foreach ($ready_to_sell as $data)
                        <tr>
                            <td>{{$data->BUILDING_NAME}}</td>
                            <td>{{$data->HP_PORT}}</td>
                        </tr>
                        @endforeach
                    </table>



                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('script')
@include('admin.javascript.javascript_dashboard')
@endsection